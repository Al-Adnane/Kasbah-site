Kasbah Safari Extension (Preview)

This is a placeholder package for launch.
Safari extensions require Xcode build/signing.
Next: ship a notarized .app or App Store listing.
