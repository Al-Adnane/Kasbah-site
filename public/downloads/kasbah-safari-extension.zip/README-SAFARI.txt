Kasbah Safari Extension — Placeholder

Safari extensions require signing (Xcode).
This ZIP is informational so the link is not broken.
Public distribution will be via Apple’s official channels.
