Kasbah Chrome Extension — Developer Preview (placeholder)

This is a placeholder ZIP to keep the developer download link non-broken.
Public distribution will be via the Chrome Web Store.

If you are building the real extension:
- unzip
- Chrome → Extensions → Developer mode
- Load unpacked → select folder
