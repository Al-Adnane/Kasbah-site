Kasbah Chrome Extension (Preview)

This is a placeholder package for launch.
Next: replace with real extension build.
Install:
1) Unzip
2) Chrome > Extensions > Developer mode
3) Load unpacked > select folder
